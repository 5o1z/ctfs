#!/bin/bash
docker run -d --name final -p 1339:1339 faas
