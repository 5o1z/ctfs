#!/bin/sh
docker build -t faas .
