# idek CPU

idek CPU is RISC-V based processor. Your goal is to retrieve the message stored in the processor's secret storage.

We have secretly received the source code for their processor, available to you in `src/`. A copy of the system rom has smuggled out of their research facility (`system.mem`). Their internal documentation also notes that `sim.sh` and `verilator` will be useful for local testing.

¯\_(ツ)\_/¯
