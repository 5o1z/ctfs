#!/usr/bin/python3

import base64
from subprocess import run
from shutil import copy

def write_memfile(path: str, start: int, data: bytes, mode: str):
    with open(path, mode) as fp:
        fp.write("\n")
        fp.write(f"@{start:08x}\n")

        words = [
            int.from_bytes(data[i : i + 4], "little") for i in range(0, len(data), 4)
        ]
        words = [f"{word:08x}" for word in words]
        words = " ".join(words)
        fp.write(words)
        fp.write("\n")

program = input("give me your code: ")
code = base64.b64decode(program)
MAX_LEN = 0x200 * 4

if len(code) > MAX_LEN:
    exit("too long")

code = code.ljust(MAX_LEN, b"\0")
CODE_START = 0x100
flag = open("flag.txt", "rb").read()

copy("system.mem", "/tmp/rom_file.mem")
write_memfile("/tmp/rom_file.mem", CODE_START, code, "a+")
write_memfile("/tmp/flag.mem", 0, flag, "w+")

handle = run("/home/user/Simulation", cwd="/tmp", check=True, capture_output=True, encoding="utf-8")
result = handle.stdout.split("took", maxsplit=1)[0] + handle.stderr
if result.startswith("x0"):
    print(result)
else:
    print("bad...")
print("done")